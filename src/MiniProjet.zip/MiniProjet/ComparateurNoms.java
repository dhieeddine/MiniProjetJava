package MiniProjet;

public interface ComparateurNoms {
	double comparer(String nom1, String nom2);

}

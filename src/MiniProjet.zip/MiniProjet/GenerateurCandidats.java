package MiniProjet;

import java.util.List;

public interface GenerateurCandidats {
	

	List<CoupleDeNom> genererCandidats(List<EntiteNom> listeNom1,List<EntiteNom> listeNoms2); 

}

package MiniProjet;

import java.util.List;

public interface Pretraiteur {
	public List<EntiteNom> pretraiter(List<EntiteNom> list);

}
 
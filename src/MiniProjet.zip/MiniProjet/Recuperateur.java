package MiniProjet;

import java.util.List;

public interface Recuperateur {
	

	List<EntiteNom> recuperer();

}

package MiniProjet;

public interface ResultatDeMatching {
	
	

	public double getScore();

}
